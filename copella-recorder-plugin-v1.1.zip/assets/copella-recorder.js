/**
 * Copella Recorder WordPress Plugin JavaScript
 * Version: 1.1
 */

(function($) {
    'use strict';
    
    // Plugin initialization
    $(document).ready(function() {
        initCopellaRecorder();
    });
    
    /**
     * Initialize Copella Recorder
     */
    function initCopellaRecorder() {
        const containers = document.querySelectorAll('#copella-recorder-container');
        
        containers.forEach(function(container) {
            const app = container.querySelector('#copella-recorder-app');
            if (app) {
                loadRecorderApp(app);
            }
        });
    }
    
    /**
     * Load the recorder application
     */
    function loadRecorderApp(container) {
        // Create iframe to load the recorder
        const iframe = document.createElement('iframe');
        iframe.src = copellaRecorder.pluginUrl + 'assets/recorder.html';
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        iframe.style.border = 'none';
        iframe.style.borderRadius = '12px';
        iframe.allow = 'microphone; camera';
        iframe.loading = 'lazy';
        
        // Add loading event
        iframe.addEventListener('load', function() {
            console.log('Copella Recorder loaded successfully');
        });
        
        // Add error handling
        iframe.addEventListener('error', function() {
            console.error('Failed to load Copella Recorder');
            showErrorMessage(container);
        });
        
        // Replace loading placeholder with iframe
        container.innerHTML = '';
        container.appendChild(iframe);
    }
    
    /**
     * Show error message if loading fails
     */
    function showErrorMessage(container) {
        container.innerHTML = `
            <div class="error-message">
                <div class="error-icon">⚠️</div>
                <h3>Ошибка загрузки</h3>
                <p>Не удалось загрузить Copella Recorder. Проверьте подключение к интернету и попробуйте обновить страницу.</p>
                <button onclick="location.reload()" class="retry-button">Попробовать снова</button>
            </div>
        `;
        
        // Add error styles
        const style = document.createElement('style');
        style.textContent = `
            .error-message {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100%;
                background: #0A0A0A;
                color: #FFFFFF;
                font-family: 'Gilroy', system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;
                padding: 40px;
                text-align: center;
            }
            .error-icon {
                font-size: 48px;
                margin-bottom: 20px;
            }
            .error-message h3 {
                margin: 0 0 15px 0;
                color: #FF453A;
                font-size: 20px;
                font-weight: 600;
            }
            .error-message p {
                margin: 0 0 25px 0;
                color: #8A8A8E;
                font-size: 14px;
                line-height: 1.5;
                max-width: 400px;
            }
            .retry-button {
                background: #8B5CF6;
                color: #FFFFFF;
                border: none;
                padding: 12px 24px;
                border-radius: 8px;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                transition: background-color 0.2s ease;
            }
            .retry-button:hover {
                background: #7C3AED;
            }
        `;
        document.head.appendChild(style);
    }
    
    /**
     * AJAX helper functions
     */
    window.copellaRecorderAjax = {
        /**
         * Get default stations
         */
        getDefaultStations: function() {
            return $.ajax({
                url: copellaRecorder.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'copella_recorder_data',
                    subaction: 'get_default_stations',
                    nonce: copellaRecorder.nonce
                }
            });
        },
        
        /**
         * Save user data
         */
        saveUserData: function(data) {
            return $.ajax({
                url: copellaRecorder.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'copella_recorder_data',
                    subaction: 'save_user_data',
                    data: data,
                    nonce: copellaRecorder.nonce
                }
            });
        }
    };
    
})(jQuery);