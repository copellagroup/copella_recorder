<?php
/**
 * Plugin Name: Copella Recorder
 * Plugin URI: https://copella.live
 * Description: Веб-приложение для прослушивания и записи интернет-радио с современным интерфейсом и микрофункциями.
 * Version: 1.1
 * Author: Copella
 * Author URI: https://copella.live
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: copella-recorder
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('COPELLA_RECORDER_VERSION', '1.1');
define('COPELLA_RECORDER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('COPELLA_RECORDER_PLUGIN_PATH', plugin_dir_path(__FILE__));

/**
 * Main Copella Recorder Plugin Class
 */
class CopellaRecorder {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_head', array($this, 'add_meta_tags'));
        add_shortcode('copella_recorder', array($this, 'render_recorder'));
        add_action('wp_ajax_copella_recorder_data', array($this, 'ajax_handler'));
        add_action('wp_ajax_nopriv_copella_recorder_data', array($this, 'ajax_handler'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load text domain for translations
        load_plugin_textdomain('copella-recorder', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        // Only load on pages with the shortcode
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'copella_recorder')) {
            wp_enqueue_script('copella-recorder', COPELLA_RECORDER_PLUGIN_URL . 'assets/copella-recorder.js', array(), COPELLA_RECORDER_VERSION, true);
            wp_enqueue_style('copella-recorder', COPELLA_RECORDER_PLUGIN_URL . 'assets/copella-recorder.css', array(), COPELLA_RECORDER_VERSION);
            
            // Localize script for AJAX
            wp_localize_script('copella-recorder', 'copellaRecorder', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('copella_recorder_nonce'),
                'version' => COPELLA_RECORDER_VERSION
            ));
        }
    }
    
    /**
     * Add meta tags for PWA support
     */
    public function add_meta_tags() {
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'copella_recorder')) {
            echo '<meta name="theme-color" content="#0A0A0A">' . "\n";
            echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
            echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">' . "\n";
        }
    }
    
    /**
     * Render the recorder shortcode
     */
    public function render_recorder($atts) {
        $atts = shortcode_atts(array(
            'width' => '100%',
            'height' => '600px',
            'theme' => 'dark'
        ), $atts);
        
        ob_start();
        ?>
        <div id="copella-recorder-container" style="width: <?php echo esc_attr($atts['width']); ?>; height: <?php echo esc_attr($atts['height']); ?>;">
            <div id="copella-recorder-app">
                <!-- Copella Recorder will be loaded here -->
                <div class="loading-placeholder">
                    <div class="spinner"></div>
                    <p>Загрузка Copella Recorder...</p>
                </div>
            </div>
        </div>
        
        <style>
        .loading-placeholder {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            background: #0A0A0A;
            color: #FFFFFF;
            font-family: 'Gilroy', system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;
        }
        
        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid rgba(255,255,255,0.2);
            border-top: 4px solid #8B5CF6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        </style>
        
        <script>
        // Load the recorder application
        document.addEventListener('DOMContentLoaded', function() {
            const container = document.getElementById('copella-recorder-app');
            if (container) {
                // Create iframe to load the recorder
                const iframe = document.createElement('iframe');
                iframe.src = '<?php echo COPELLA_RECORDER_PLUGIN_URL; ?>recorder.html';
                iframe.style.width = '100%';
                iframe.style.height = '100%';
                iframe.style.border = 'none';
                iframe.style.borderRadius = '12px';
                iframe.allow = 'microphone; camera';
                
                container.innerHTML = '';
                container.appendChild(iframe);
            }
        });
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * AJAX handler for plugin data
     */
    public function ajax_handler() {
        check_ajax_referer('copella_recorder_nonce', 'nonce');
        
        $action = sanitize_text_field($_POST['action'] ?? '');
        
        switch ($action) {
            case 'get_default_stations':
                $this->get_default_stations();
                break;
            case 'save_user_data':
                $this->save_user_data();
                break;
            default:
                wp_die('Invalid action');
        }
    }
    
    /**
     * Get default radio stations
     */
    private function get_default_stations() {
        $default_stations = array(
            array(
                'name' => 'Европа Плюс',
                'url' => 'https://hls-01-regions.emgsound.ru/11_msk/playlist.m3u8',
                'icon' => 'https://www.radio-city.fm/wp-content/uploads/2017/04/logo-europa-plus.png'
            ),
            array(
                'name' => 'Радио РБК',
                'url' => 'https://hls-01-rbc.hostingradio.ru/rbc/playlist.m3u8',
                'icon' => 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/RBC_logo_2019.svg/1200px-RBC_logo_2019.svg.png'
            )
        );
        
        wp_send_json_success($default_stations);
    }
    
    /**
     * Save user data
     */
    private function save_user_data() {
        $user_id = get_current_user_id();
        $data = sanitize_text_field($_POST['data'] ?? '');
        
        if ($user_id && $data) {
            update_user_meta($user_id, 'copella_recorder_data', $data);
            wp_send_json_success('Data saved');
        } else {
            wp_send_json_error('Invalid data');
        }
    }
}

// Initialize the plugin
new CopellaRecorder();

/**
 * Activation hook
 */
register_activation_hook(__FILE__, 'copella_recorder_activate');

function copella_recorder_activate() {
    // Create necessary database tables or options
    add_option('copella_recorder_version', COPELLA_RECORDER_VERSION);
    add_option('copella_recorder_activated', true);
}

/**
 * Deactivation hook
 */
register_deactivation_hook(__FILE__, 'copella_recorder_deactivate');

function copella_recorder_deactivate() {
    // Clean up if needed
    delete_option('copella_recorder_activated');
}